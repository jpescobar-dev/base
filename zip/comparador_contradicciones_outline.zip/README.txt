Comparador de contradicciones entre snapshots

Incluye:
- ContradiccionComparatorService
- ComparadorContradiccionesController
- Vista Blade del comparador con iconos simples y outline
- Snippet de ruta

Qué compara:
- contradicciones nuevas
- contradicciones resueltas
- contradicciones persistentes
- contradicciones modificadas

Requisitos:
- Tener persistencia de contradicciones ya implementada
- Tener relación contradicciones en SnapshotRevisionContractual
- Cargar contradicciones en snapshots

Pasos:
1. Copiar archivos respetando rutas
2. Agregar la ruta en web.php
3. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
