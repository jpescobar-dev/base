Normalización de json_resultado

Incluye:
- AnalisisRevisionContractualController actualizado

Objetivo:
- Tomar output.0.content.0.text
- Intentar convertirlo a JSON real
- Guardarlo normalizado en snapshots_revision_contractual.json_resultado

Pasos:
1. Copiar el controller respetando la ruta.
2. Verificar el cast del modelo SnapshotRevisionContractual.
3. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
4. Volver a correr "Analizar con IA"
5. Verificar en Tinker

Notas:
- Si no se puede parsear, se guarda el texto original como respaldo.
- Si el modelo no tiene cast array, la lectura seguirá viéndose como string.
