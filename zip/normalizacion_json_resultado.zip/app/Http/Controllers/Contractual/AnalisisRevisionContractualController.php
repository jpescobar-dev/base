<?php

namespace App\Http\Controllers\Contractual;

use App\Http\Controllers\Controller;
use App\Models\RevisionContractual;
use App\Models\SnapshotRevisionContractual;
use App\Services\Contractual\OpenAIRevisionContractualService;
use Illuminate\Http\RedirectResponse;

class AnalisisRevisionContractualController extends Controller
{
    public function store(
        RevisionContractual $revision,
        OpenAIRevisionContractualService $service
    ): RedirectResponse {
        \Log::info('Entró al análisis', [
            'revision_id' => $revision->id,
            'user_id' => auth()->id(),
        ]);

        $data = $service->analizar($revision);

        \Log::info('Respuesta análisis', [
            'revision_id' => $revision->id,
            'keys' => array_keys($data),
        ]);

        $outputText = data_get($data, 'output.0.content.0.text');

        $decoded = null;

        if ($outputText) {
            $decoded = json_decode($outputText, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                $clean = stripslashes($outputText);
                $decoded = json_decode($clean, true);
            }
        }

        if (!$decoded) {
            \Log::warning('No se pudo parsear JSON de OpenAI', [
                'revision_id' => $revision->id,
                'outputText' => $outputText,
            ]);
        }

        $jsonFinal = $decoded ?: $outputText;

        $ultimaVersion = $revision->snapshots()->max('numero_version') ?? 0;
        $nuevaVersion = $ultimaVersion + 1;

        SnapshotRevisionContractual::where('revision_contractual_id', $revision->id)
            ->update(['es_actual' => false]);

        $snapshot = SnapshotRevisionContractual::create([
            'revision_contractual_id' => $revision->id,
            'numero_version' => $nuevaVersion,
            'tipo_ejecucion' => 'openai_debug',
            'resumen' => 'Análisis IA ejecutado correctamente.',
            'json_resultado' => $jsonFinal,
            'es_actual' => true,
            'user_id' => auth()->id(),
        ]);

        \Log::info('Snapshot IA creado', [
            'snapshot_id' => $snapshot->id,
            'revision_id' => $revision->id,
            'numero_version' => $snapshot->numero_version,
            'json_normalizado' => is_array($jsonFinal),
        ]);

        return redirect()
            ->route('contractual.revisiones.snapshots.show', [$revision, $snapshot])
            ->with('success', 'Análisis ejecutado y guardado correctamente.');
    }
}
