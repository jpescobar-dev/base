Mejoras de capa visual para documentos

Incluye:
- badges de estado
- resumen superior de documentos
- filtros por tipo, fuente y estado
- iconos simples outline por tipo
- tabla embebida mejorada en revisiones/show
- tabla completa mejorada en documentos/index

Respaldo en repo:
Te conviene generar respaldo en GitHub ahora, antes de seguir con reprocesado o trazabilidad de documentos.
Este es un buen punto de corte porque:
- OCR ya funciona
- DOCX ya funciona
- contradicciones ya existen
- comparador ya existe
- capa visual ya está bastante madura
