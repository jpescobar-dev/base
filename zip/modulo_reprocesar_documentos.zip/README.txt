Módulo de reprocesamiento de documentos

Incluye:
- DocumentoRevisionContractualController actualizado con método reprocess()
- snippet para la tabla embebida en revisiones/show.blade.php
- snippet para la tabla completa en documentos/index.blade.php
- snippet de ruta

Qué hace:
- agrega botón Reprocesar documento
- vuelve a ejecutar el pipeline de extracción/OCR/Word
- actualiza estados y textos del documento sin subirlo de nuevo

Cuándo conviene usarlo:
- falló OCR
- cambiaste binarios o configuración
- corregiste el pipeline
- quieres volver a intentar extracción

Instalación:
1. Copiar controller
2. Agregar ruta POST de reprocess
3. Reemplazar los bloques de acciones de las tablas
4. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
