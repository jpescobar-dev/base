Mejora real de la tabla Documentos Asociados embebida en la revisión

Incluye:
- Revision show.blade.php corregido
- DocumentoRevisionContractualController con show/preview/download
- Vista de documento con preview PDF embebido
- Rutas necesarias

Mejoras:
- Columna Tipo completa
- Columna Tamaño usando peso_bytes
- Iconos simples y outline según tipo de archivo
- Botón Ver abre vista con preview embebido para PDF
- Botón Descargar separado
- DOCX abre descarga controlada

Pasos:
1. Copiar archivos respetando rutas
2. Agregar rutas en web.php
3. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
