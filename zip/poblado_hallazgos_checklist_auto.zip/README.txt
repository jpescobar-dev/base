Poblado automático de hallazgos y checklist

Incluye:
- AnalisisRevisionContractualController actualizado

Objetivo:
- Ejecutar análisis IA
- Normalizar json_resultado
- Crear snapshot nuevo
- Poblar automáticamente:
  - hallazgos_revision_contractual
  - checklist_revision_contractual

Pasos:
1. Copiar el controller respetando la ruta.
2. Verificar cast array en SnapshotRevisionContractual.
3. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
4. Volver a ejecutar "Analizar con IA"
5. Revisar el snapshot nuevo y sus relaciones

Notas:
- Si la respuesta IA no puede parsearse a JSON, no guarda registros.
- referencia_documental y otros campos avanzados quedan en null por ahora.
- Este paso asume que las tablas de hallazgos y checklist ya existen y funcionan.
