Mejora de vista de documentos asociados

Incluye:
- DocumentoRevisionContractualController con método show()
- Vista index.blade.php mejorada
- Snippet de rutas

Mejoras:
- Columna Tipo completa
- Columna Tamaño completa
- Botón Ver documento funcionando en nueva pestaña

Pasos:
1. Copiar archivos respetando rutas
2. Agregar la ruta show en web.php
3. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
