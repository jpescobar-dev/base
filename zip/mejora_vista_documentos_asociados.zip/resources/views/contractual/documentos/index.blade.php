@extends('layouts.theme.app')

@section('content')
<div class="container-fluid">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold mb-1">Documentos Asociados</h3>
            <p class="text-muted mb-0">Revisión #{{ $revision->id }} · {{ $revision->titulo }}</p>
        </div>

        <div class="d-flex gap-2">
            <a href="{{ route('contractual.revisiones.show', $revision) }}" class="btn btn-outline-secondary">
                Volver
            </a>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white border-0 pt-3 pb-0">
            <h5 class="fw-bold mb-0">Documentos Asociados</h5>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th style="width: 70px;">ID</th>
                            <th>Nombre original</th>
                            <th style="width: 220px;">Tipo</th>
                            <th style="width: 140px;">Tamaño</th>
                            <th style="width: 180px;">Usuario</th>
                            <th style="width: 170px;">Fecha</th>
                            <th style="width: 170px;" class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($revision->documentos->sortByDesc('id') as $documento)
                            <tr>
                                <td>{{ $documento->id }}</td>
                                <td>
                                    <div class="fw-medium">{{ $documento->nombre_original }}</div>
                                    <div class="small text-muted">{{ $documento->mime_type ?: '-' }}</div>
                                </td>
                                <td>
                                    <div>{{ $documento->tipo_documento ?: ($documento->extension ? strtoupper($documento->extension) : '-') }}</div>
                                    @if($documento->fuente_texto)
                                        <div class="small text-muted">Fuente: {{ strtoupper($documento->fuente_texto) }}</div>
                                    @endif
                                </td>
                                <td>
                                    @if(!is_null($documento->peso_bytes))
                                        {{ number_format($documento->peso_bytes / 1024, 1, ',', '.') }} KB
                                    @else
                                        -
                                    @endif
                                </td>
                                <td>{{ $documento->usuario->name ?? 'Sin usuario' }}</td>
                                <td>{{ optional($documento->created_at)->format('d-m-Y H:i') }}</td>
                                <td class="text-center">
                                    <div class="d-inline-flex gap-2">
                                        <a href="{{ route('contractual.revisiones.documentos.show', [$revision, $documento]) }}"
                                           class="btn btn-outline-primary btn-sm"
                                           target="_blank"
                                           title="Ver documento">
                                            <i class="fa-regular fa-eye"></i>
                                        </a>

                                        <form action="{{ route('contractual.revisiones.documentos.destroy', [$revision, $documento]) }}"
                                              method="POST"
                                              onsubmit="return confirm('¿Eliminar este documento?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-outline-danger btn-sm" title="Eliminar documento">
                                                <i class="fa-regular fa-trash-can"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">
                                    No existen documentos asociados a esta revisión.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
