Módulo de tipos documentales y exigibilidad por revisión

Incluye:
- tabla maestra tipos_documento_contractual
- tabla revision_tipos_documento
- modelos
- controller de catálogo
- controller de configuración por revisión
- servicio validador previo al análisis
- vistas base

Objetivo:
- definir jerarquía documental formal
- marcar criticidad y peso
- permitir que el usuario active o desactive qué tipos aplican en cada revisión
- permitir marcar cuáles son obligatorios

Diseño:
1. El catálogo define jerarquía base
2. La revisión define aplicabilidad concreta
3. El análisis IA debe usar esta configuración antes de ejecutarse

Pasos:
1. Copiar archivos
2. Agregar rutas
3. Agregar relaciones de modelo
4. Ejecutar:
   php artisan migrate
   composer dump-autoload
   php artisan optimize:clear
