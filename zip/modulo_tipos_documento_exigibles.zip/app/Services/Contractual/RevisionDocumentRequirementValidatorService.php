<?php

namespace App\Services\Contractual;

use App\Models\RevisionContractual;

class RevisionDocumentRequirementValidatorService
{
    public function validate(RevisionContractual $revision): array
    {
        $revision->load([
            'tiposDocumentoConfigurados.tipo',
            'documentos',
        ]);

        $requeridos = $revision->tiposDocumentoConfigurados
            ->where('aplica', true)
            ->where('obligatorio', true);

        $faltantes = [];
        $presentesCriticos = 0;

        foreach ($requeridos as $cfg) {
            $tipo = $cfg->tipo;
            if (!$tipo) {
                continue;
            }

            $encontrado = $revision->documentos->first(function ($doc) use ($tipo) {
                $base = mb_strtolower(trim(($doc->tipo_documento ?: '') . ' ' . ($doc->nombre_original ?: '')));
                return str_contains($base, mb_strtolower($tipo->nombre))
                    || str_contains($base, mb_strtolower($tipo->codigo));
            });

            if (!$encontrado) {
                $faltantes[] = $tipo->nombre;
            } elseif ($tipo->es_critico) {
                $presentesCriticos++;
            }
        }

        $errores = [];

        if ($requeridos->count() === 0) {
            $errores[] = 'No existen tipos documentales obligatorios y aplicables configurados para esta revisión.';
        }

        if ($presentesCriticos < 2) {
            $errores[] = 'No existe un mínimo suficiente de documentos críticos presentes para un análisis confiable.';
        }

        if (!empty($faltantes)) {
            $errores[] = 'Faltan documentos obligatorios: ' . implode(', ', $faltantes) . '.';
        }

        return [
            'valido' => empty($errores),
            'errores' => $errores,
            'faltantes' => $faltantes,
            'obligatorios_configurados' => $requeridos->count(),
            'criticos_presentes' => $presentesCriticos,
        ];
    }
}
