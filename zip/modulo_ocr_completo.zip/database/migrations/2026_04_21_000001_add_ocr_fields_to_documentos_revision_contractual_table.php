<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('documentos_revision_contractual', function (Blueprint $table) {
            if (!Schema::hasColumn('documentos_revision_contractual', 'texto_ocr')) {
                $table->longText('texto_ocr')->nullable()->after('texto_extraido');
            }

            if (!Schema::hasColumn('documentos_revision_contractual', 'ocr_estado')) {
                $table->string('ocr_estado', 40)->nullable()->after('extraccion_estado');
            }

            if (!Schema::hasColumn('documentos_revision_contractual', 'fuente_texto')) {
                $table->string('fuente_texto', 20)->nullable()->after('tiene_texto_extraible');
            }
        });
    }

    public function down(): void
    {
        Schema::table('documentos_revision_contractual', function (Blueprint $table) {
            if (Schema::hasColumn('documentos_revision_contractual', 'fuente_texto')) {
                $table->dropColumn('fuente_texto');
            }

            if (Schema::hasColumn('documentos_revision_contractual', 'ocr_estado')) {
                $table->dropColumn('ocr_estado');
            }

            if (Schema::hasColumn('documentos_revision_contractual', 'texto_ocr')) {
                $table->dropColumn('texto_ocr');
            }
        });
    }
};
