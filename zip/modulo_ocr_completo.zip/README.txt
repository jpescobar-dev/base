MÓDULO OCR COMPLETO

Incluye:
- config/ocr.php
- migración para campos OCR
- PdfTextExtractorService
- PdfOcrExtractorService
- DocumentoTextPipelineService
- DocumentoRevisionContractualController actualizado
- DocumentoRevisionContractual model actualizado

REQUISITOS
1. Tesseract instalado
2. Poppler / pdftoppm instalado
3. Ambos binarios en PATH, o configurados en .env

ENV SUGERIDO
OCR_ENABLED=true
OCR_TESSERACT_BINARY=tesseract
OCR_PDFTOPPM_BINARY=pdftoppm
OCR_LANGUAGE=spa
OCR_DPI=300
OCR_MAX_PAGES=20

PASOS
1. Copiar archivos respetando rutas
2. Ejecutar:
   php artisan migrate
   composer dump-autoload
   php artisan optimize:clear
3. Subir un PDF con texto y un PDF escaneado para probar

RESULTADO ESPERADO
- PDF con texto: fuente_texto = texto, extraccion_estado = EXTRAIDO
- PDF escaneado: fuente_texto = ocr, extraccion_estado = EXTRAIDO_OCR
- PDF ilegible: ocr_estado con detalle y mensaje de error controlado

NOTA
Este módulo no reemplaza tu lógica de prompt.
Solo mejora la etapa de extracción previa para que los documentos escaneados lleguen legibles al análisis IA.
