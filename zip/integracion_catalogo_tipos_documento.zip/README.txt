Integración del catálogo de tipos documentales con documentos reales

Incluye:
- migración para agregar tipo_documento_contractual_id a documentos_revision_contractual
- modelo DocumentoRevisionContractual actualizado
- DocumentoRevisionContractualController actualizado
- validador por revisión ajustado a FK real
- snippets para vistas y controller

Objetivo:
- pasar de tipo_documento texto libre a una referencia estructurada
- mantener el texto libre como respaldo temporal
- usar el catálogo en validación y futuras contradicciones

Pasos:
1. Copiar archivos
2. Ejecutar:
   php artisan migrate
   composer dump-autoload
   php artisan optimize:clear
3. Ajustar RevisionContractualController@show para enviar $tiposDocumentales
4. Reemplazar el select/input del formulario de carga
5. Ajustar la columna Tipo de la tabla

Siguiente paso natural:
- resolver contradicciones con peso_jerarquico y documento prevalente real
