Persistencia de resultado OpenAI en Snapshot

Incluye:
- AnalisisRevisionContractualController actualizado

Objetivo:
- Tomar la respuesta útil de OpenAI desde:
  output.0.content.0.text
- Guardarla en:
  snapshots_revision_contractual.json_resultado
- Crear un snapshot nuevo marcado como actual

Pasos:
1. Copiar el controller respetando la ruta.
2. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
3. Volver a ejecutar "Analizar con IA"
4. Verificar resultado en Tinker

Notas:
- Si no existe output_text, guarda el JSON completo como respaldo.
