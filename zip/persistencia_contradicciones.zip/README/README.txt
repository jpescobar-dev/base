Persistencia de contradicciones documentales

Incluye:
- Migración: contradicciones_revision_contractual
- Modelo: ContradiccionRevisionContractual
- AnalisisRevisionContractualController actualizado para persistir contradicciones
- Partial blade para mostrar contradicciones persistidas

Qué agrega:
1. Guarda cada contradicción como registro independiente
2. Resuelve documento preferente según jerarquía documental
3. Prepara la base para comparador, filtros y reportes

Ajustes manuales recomendados:
1. En SnapshotRevisionContractual model agregar:
   public function contradicciones() { return $this->hasMany(ContradiccionRevisionContractual::class, 'snapshot_revision_contractual_id'); }
2. En el controller show del snapshot cargar:
   $snapshot->load(['hallazgos', 'checklist', 'contradicciones']);
3. En la vista show incluir el partial:
   @include('contractual.snapshots.partials.contradicciones')

Pasos:
- Copiar archivos
- php artisan migrate
- composer dump-autoload
- php artisan optimize:clear
