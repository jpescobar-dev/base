Integración completa de contradicciones documentales

Incluye:
- PromptRevisionContractualBuilderService actualizado
- AnalisisRevisionContractualController actualizado
- show.blade.php del snapshot actualizado

Qué agrega:
1. Detecta contradicciones heurísticas entre documentos antes del análisis
2. Inserta las contradicciones en el prompt
3. Guarda contradicciones en json_resultado
4. Muestra contradicciones en la vista del snapshot

Requisitos:
- Tener ya instalado DocumentContradictionDetectorService.php del módulo anterior
- Mantener los partials de checklist por capas ya existentes

Pasos:
1. Copiar archivos respetando rutas
2. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
3. Ejecutar un nuevo análisis sobre una revisión con documentos cargados

Resultado:
- El snapshot mostrará contradicciones documentales detectadas
- El prompt tendrá más contexto para analizar coherencia documental
