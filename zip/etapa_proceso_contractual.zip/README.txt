Módulo etapa del proceso contractual

Incluye:
- migración para agregar etapa_proceso_contractual a revisiones_contractuales
- modelo RevisionContractual actualizado
- validador documental sensible a etapa
- PromptRevisionContractualBuilderService con etapa en contexto dinámico
- snippets para create/edit/show y controller

Objetivo:
- distinguir exigencias según etapa del expediente
- reducir falsos hallazgos
- mejorar calidad del prompt y del gate documental

Pasos:
1. Copiar archivos
2. Ejecutar:
   php artisan migrate
   composer dump-autoload
   php artisan optimize:clear
3. Integrar el campo en create/edit
4. Mostrar la etapa en show
5. Ajustar store/update del controller

Siguiente paso natural:
- adaptar el checklist y hallazgos para responder diferente según etapa
