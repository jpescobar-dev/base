MÓDULO DE DETECCIÓN DE CONTRADICCIONES ENTRE DOCUMENTOS

Qué hace:
- Compara automáticamente campos relevantes entre documentos del expediente
- Detecta contradicciones en:
  - ID de licitación
  - proveedor
  - plazo en meses
  - monto en UF
  - garantía en UF
  - fecha de inicio

Archivos:
- app/Services/Contractual/DocumentContradictionDetectorService.php
- snippets para integrarlo al PromptRevisionContractualBuilderService
- snippet opcional para agregarlo al snapshot JSON

Lógica:
- Heurística, no jurídica definitiva
- Sirve como capa previa de control y apoyo al prompt
- La contradicción detectada debe luego ser validada por revisión documental humana

Instalación:
1. Copiar servicio en app/Services/Contractual
2. Integrar snippet del builder
3. Opcional: guardar contradicciones en json_resultado del snapshot
4. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
