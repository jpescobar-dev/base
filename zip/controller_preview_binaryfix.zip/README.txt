Corrección de tipo de retorno en preview()

Cambio aplicado:
- preview() retorna BinaryFileResponse
- import correcto: Symfony\Component\HttpFoundation\BinaryFileResponse

Después de copiar:
php artisan optimize:clear
