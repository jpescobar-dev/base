Ajuste simple de resumen de documentos

Problema:
Los conteos se veían inconsistentes porque se mezclaban dimensiones:
- tipo archivo
- fuente de texto
- estado

Solución:
Se separan visualmente en 3 bloques:
1. Formato
2. Fuente de texto
3. Estado

Resultado:
- no se suman categorías incompatibles
- se evita confusión
- no cambia diseño general

Uso:
Reemplazar el bloque actual de resumen en:
resources/views/contractual/revisiones/show.blade.php
