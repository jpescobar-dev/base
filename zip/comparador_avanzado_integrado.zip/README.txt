Comparador avanzado integrado

Incluye:
- Controller ComparadorSnapshotController
- Vista compare.blade.php
- Partials para hallazgos y checklist
- Snippet de ruta

Pasos:
1. Copiar archivos respetando rutas.
2. Agregar la ruta en routes/web.php.
3. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear

Uso:
- Abrir la ruta de comparación con dos snapshots de la misma revisión.
- Resume hallazgos nuevos, eliminados y modificados.
- Resume checklist nuevos, eliminados, mejorados y empeorados.
