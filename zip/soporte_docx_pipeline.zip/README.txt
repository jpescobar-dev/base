Soporte DOCX para pipeline contractual

Incluye:
- WordTextExtractorService.php
- DocumentoTextPipelineService.php actualizado
- DocumentoRevisionContractualController.php actualizado

Qué hace:
- Evita enviar archivos DOCX a extractores PDF
- Soporta extracción de texto desde DOCX
- Mantiene OCR solo para PDF escaneado
- Bloquea formatos no soportados

Requisitos:
- phpoffice/phpword instalado

Pasos:
1. Copiar archivos respetando rutas
2. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
3. Probar subiendo:
   - un PDF con texto
   - un PDF escaneado
   - un DOCX

Resultados esperados:
- PDF con texto -> fuente_texto = texto
- PDF escaneado -> fuente_texto = ocr
- DOCX -> fuente_texto = word
