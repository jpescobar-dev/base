Evolución de hallazgos y contradicciones entre snapshots

Incluye:
- SnapshotEvolutionService
- partial Blade de evolución
- snippets para integrar en SnapshotRevisionContractualController@show
- snippet para incluir la vista en snapshot/show.blade.php

Qué hace:
- clasifica hallazgos en nuevos, persistentes, corregidos y agravados
- clasifica contradicciones en nuevas, persistentes, resueltas y agravadas
- permite seguimiento real entre versiones

Pasos:
1. Copiar archivos
2. Integrar snippet del controller show
3. Incluir partial en snapshot/show.blade.php
4. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear

Resultado:
- seguimiento evolutivo entre snapshots
- mejor control de iteraciones
- base para auditoría y revisión continua
