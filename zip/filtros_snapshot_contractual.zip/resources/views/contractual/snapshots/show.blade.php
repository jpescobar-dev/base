@extends('layouts.theme.app')

@section('content')
<div class="container-fluid">

    <h3 class="fw-bold mb-4">Snapshot Revisión Contractual</h3>

    {{-- FILTROS --}}
    <div class="card mb-4 shadow-sm">
        <div class="card-body">

            <form method="GET">

                <div class="row">

                    <div class="col-md-4">
                        <label>Filtrar Hallazgos</label>
                        <select name="criticidad" class="form-control">
                            <option value="">Todos</option>
                            <option value="alta">Alta</option>
                            <option value="media">Media</option>
                            <option value="baja">Baja</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label>Filtrar Checklist</label>
                        <select name="estado" class="form-control">
                            <option value="">Todos</option>
                            <option value="cumple">Cumple</option>
                            <option value="no_cumple">No cumple</option>
                            <option value="pendiente_verificar">Pendiente</option>
                            <option value="no_se_encuentra">No se encuentra</option>
                        </select>
                    </div>

                    <div class="col-md-4 d-flex align-items-end">
                        <button class="btn btn-primary w-100">Filtrar</button>
                    </div>

                </div>

            </form>

        </div>
    </div>

    @php
        $criticidad = request('criticidad');
        $estado = request('estado');

        $hallazgos = $snapshot->hallazgos;

        if ($criticidad) {
            $hallazgos = $hallazgos->where('nivel_criticidad', $criticidad);
        }

        $checklist = $snapshot->checklist;

        if ($estado) {
            $checklist = $checklist->where('estado_item', $estado);
        }
    @endphp

    {{-- HALLAZGOS --}}
    <div class="row mb-4">
        <h5 class="fw-bold">Hallazgos</h5>

        @foreach($hallazgos as $h)
        <div class="col-md-6 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6>{{ $h->titulo }}</h6>

                    <span class="badge 
                        @if($h->nivel_criticidad == 'alta') bg-danger
                        @elseif($h->nivel_criticidad == 'media') bg-warning text-dark
                        @else bg-success
                        @endif">
                        {{ $h->nivel_criticidad }}
                    </span>

                    <p class="mt-2">{{ $h->observacion }}</p>
                </div>
            </div>
        </div>
        @endforeach
    </div>

    {{-- CHECKLIST --}}
    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white">
            Checklist
        </div>

        <div class="card-body table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Item</th>
                        <th>Estado</th>
                        <th>Observación</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($checklist as $c)
                    <tr>
                        <td>{{ $c->orden }}</td>
                        <td>{{ $c->item }}</td>
                        <td>{{ $c->estado_item }}</td>
                        <td>{{ $c->observacion }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

</div>
@endsection
