Modificación visual del resumen de documentos en show.blade.php

Qué cambia:
- separa visualmente el tipo de archivo y la forma de extracción
- bloque izquierdo: tipo de archivo
- bloque derecho: forma de extracción
- colores suaves distintos
- iconos pequeños y outline
- mantiene el mismo contenido funcional

Archivo incluido:
- resources/views/contractual/revisiones/show.blade.php
