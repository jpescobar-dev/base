<?php

namespace App\Http\Controllers\Contractual;

use App\Http\Controllers\Controller;
use App\Models\SnapshotRevisionContractual;

class ComparadorSnapshotController extends Controller
{
    public function compare($id1, $id2)
    {
        $s1 = SnapshotRevisionContractual::with(['hallazgos','checklist'])->findOrFail($id1);
        $s2 = SnapshotRevisionContractual::with(['hallazgos','checklist'])->findOrFail($id2);

        return view('contractual.snapshots.compare', compact('s1','s2'));
    }
}
