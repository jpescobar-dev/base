@extends('layouts.theme.app')

@section('content')
<div class="container-fluid">

    <h3 class="mb-4">Comparador de Snapshots</h3>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-dark text-white">Snapshot {{ $s1->numero_version }}</div>
                <div class="card-body">
                    <p><strong>Hallazgos:</strong> {{ $s1->hallazgos->count() }}</p>
                    <p><strong>Checklist:</strong> {{ $s1->checklist->count() }}</p>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-dark text-white">Snapshot {{ $s2->numero_version }}</div>
                <div class="card-body">
                    <p><strong>Hallazgos:</strong> {{ $s2->hallazgos->count() }}</p>
                    <p><strong>Checklist:</strong> {{ $s2->checklist->count() }}</p>
                </div>
            </div>
        </div>
    </div>

    <h5>Cambios en Hallazgos</h5>
    <ul>
        @foreach($s2->hallazgos as $h)
            @if(!$s1->hallazgos->contains('titulo', $h->titulo))
                <li class="text-success">Nuevo: {{ $h->titulo }}</li>
            @endif
        @endforeach

        @foreach($s1->hallazgos as $h)
            @if(!$s2->hallazgos->contains('titulo', $h->titulo))
                <li class="text-danger">Eliminado: {{ $h->titulo }}</li>
            @endif
        @endforeach
    </ul>

</div>
@endsection
