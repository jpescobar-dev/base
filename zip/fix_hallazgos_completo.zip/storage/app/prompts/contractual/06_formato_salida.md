# 6. FORMATO DE SALIDA

La respuesta debe ser EXCLUSIVAMENTE en formato JSON válido.

Estructura obligatoria:

{
  "resumen": {
    "tipo_contrato": "",
    "entidad": "",
    "riesgo_general": "alto|medio|bajo",
    "observaciones_clave": []
  },
  "hallazgos": [
    {
      "titulo": "",
      "tipo_riesgo": "juridico|administrativo|financiero|control",
      "criticidad": "alta|media|baja",
      "descripcion": "",
      "recomendacion": ""
    }
  ],
  "checklist": {
    "existencia": [
      {
        "item": "",
        "estado": "cumple|no_se_encuentra|pendiente",
        "observacion": ""
      }
    ],
    "coherencia": [
      {
        "item": "",
        "estado": "cumple|pendiente",
        "observacion": ""
      }
    ],
    "cumplimiento": [
      {
        "item": "",
        "estado": "cumple|no_cumple|pendiente",
        "observacion": ""
      }
    ]
  }
}

## FORMATO DE HALLAZGOS OBLIGATORIO

Cada hallazgo debe tener exactamente esta estructura:

{
  "titulo": "",
  "tipo_riesgo": "juridico|administrativo|financiero|control",
  "criticidad": "alta|media|baja",
  "descripcion": "",
  "recomendacion": ""
}

Reglas:
- "titulo" debe ser breve, claro y obligatorio.
- "tipo_riesgo" debe usar solo los valores permitidos.
- "criticidad" debe usar solo: alta, media, baja.
- "descripcion" debe explicar el hallazgo de manera concreta.
- "recomendacion" debe indicar la acción sugerida.
- No usar otras claves para hallazgos.

## REGLAS DE CAPAS

### EXISTENCIA
Verifica si el documento o antecedente existe en el expediente.
- Cumple → existe
- No se encuentra → no existe
- Pendiente → no es posible confirmar

### COHERENCIA
Verifica concordancia entre documentos.
- Cumple → no hay contradicción
- Pendiente → hay contradicción o inconsistencia

### CUMPLIMIENTO
Evalúa si lo exigido se cumple.
- Cumple → se cumple
- No cumple → incumplimiento claro
- Pendiente → no es posible concluir

## REGLAS GENERALES

- No mezclar capas
- No inferir
- Si falta documento clave → usar "no_se_encuentra"
- Si hay contradicción → usar "pendiente"
- Priorizar análisis sobre descripción
