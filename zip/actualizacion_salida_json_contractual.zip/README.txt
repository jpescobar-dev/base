Actualización de salida JSON para revisión contractual

Incluye:
- Archivo 06_formato_salida.md actualizado

Objetivo:
- Forzar a la IA a responder exclusivamente en JSON válido
- Preparar el sistema para la siguiente etapa:
  poblar hallazgos y checklist en base de datos

Pasos:
1. Copiar el archivo a:
   storage/app/prompts/contractual/06_formato_salida.md
2. Ejecutar:
   php artisan optimize:clear
3. Volver a correr "Analizar con IA"
4. Verificar el nuevo json_resultado en Tinker

Siguiente etapa:
- mapear el JSON a tablas de hallazgos y checklist
