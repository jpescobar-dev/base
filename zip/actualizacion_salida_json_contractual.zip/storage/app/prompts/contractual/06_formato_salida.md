## FORMATO DE SALIDA OBLIGATORIO

La respuesta debe ser EXCLUSIVAMENTE en formato JSON válido.

No incluir texto fuera del JSON.
No incluir explicaciones adicionales.
No usar markdown.
No usar encabezados.
No usar listas.
No usar frases introductorias ni de cierre.

Estructura obligatoria:

{
  "resumen": {
    "tipo_contrato": "",
    "entidad": "",
    "riesgo_general": "alto|medio|bajo",
    "observaciones_clave": []
  },
  "hallazgos": [
    {
      "titulo": "",
      "tipo_riesgo": "juridico|administrativo|financiero|control",
      "descripcion": "",
      "criticidad": "alta|media|baja",
      "recomendacion": ""
    }
  ],
  "checklist": [
    {
      "item": "",
      "estado": "cumple|no_cumple|no_se_encuentra|pendiente",
      "observacion": ""
    }
  ]
}

Reglas obligatorias de salida:

1. Si no hay información suficiente, igualmente debes responder en JSON válido.
2. No dejes de responder por falta de antecedentes; informa la insuficiencia dentro del JSON.
3. "observaciones_clave" debe ser un arreglo de textos breves.
4. "hallazgos" puede estar vacío si no existen hallazgos acreditados.
5. "checklist" debe contener solo ítems sustentables con la documentación disponible.
6. Usa únicamente estos estados para checklist:
   - "cumple"
   - "no_cumple"
   - "no_se_encuentra"
   - "pendiente"
7. Usa únicamente estos niveles de criticidad:
   - "alta"
   - "media"
   - "baja"
8. Usa únicamente estos tipos de riesgo:
   - "juridico"
   - "administrativo"
   - "financiero"
   - "control"
