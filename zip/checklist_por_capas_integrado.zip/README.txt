Checklist por capas integrado

Incluye:
- Migración para agregar tipo_checklist
- AnalisisRevisionContractualController actualizado
- Modelo ChecklistRevisionContractual actualizado
- Vista snapshot show adaptada a capas
- Partial reutilizable para tabla de checklist

Pasos:
1. Copiar los archivos respetando rutas.
2. Ejecutar:
   php artisan migrate
   composer dump-autoload
   php artisan optimize:clear
3. Volver a correr "Analizar con IA"

Resultado esperado:
- Se guarda checklist separado por capas:
  existencia, coherencia, cumplimiento
- La vista muestra tres bloques diferenciados
