Ajuste de timeout y tamaño de prompt contractual

Incluye:
- OpenAIRevisionContractualService actualizado
- PromptRevisionContractualBuilderService actualizado

Cambios:
- connectTimeout = 30
- timeout = 300
- log del tamaño del prompt
- límite de 4 documentos
- recorte de 8000 caracteres por documento

Pasos:
1. Copiar archivos respetando rutas
2. Ejecutar:
   composer dump-autoload
   php artisan optimize:clear
3. Volver a ejecutar Analizar con IA
4. Revisar storage/logs/laravel.log para ver tamaño del prompt
