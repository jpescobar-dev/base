Módulo sensibilidad por etapa (checklist + prompt)

Incluye:
- ajuste automático de checklist según etapa
- reglas de prompt específicas por etapa

Qué agrega:
- estado "no_aplica"
- estado "pendiente_etapa"
- reducción de falsos hallazgos
- análisis más realista

Pasos:
1. Copiar archivos
2. Integrar snippets
3. Probar análisis en distintas etapas

Resultado:
- análisis contextual
- checklist más inteligente
- menos ruido
