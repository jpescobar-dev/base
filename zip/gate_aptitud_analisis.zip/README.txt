Gate de aptitud para análisis

Incluye:
- Servicio de evaluación previa
- Partial Blade de visualización
- Snippet de integración en controller

Función:
- Evalúa si la revisión está en condiciones de análisis IA
- Bloquea ejecución si no cumple mínimos
- Muestra faltantes y estado al usuario

Pasos:
1. Copiar archivos
2. Enviar variable $gate desde controller:
   $gate = app(RevisionAnalysisGateService::class)->evaluate($revision);
3. Incluir partial en vista
4. Bloquear botón de análisis si no está apto

Resultado:
- Evita análisis deficientes
- Mejora calidad del sistema
