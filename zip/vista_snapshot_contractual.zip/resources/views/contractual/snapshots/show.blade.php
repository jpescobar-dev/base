@extends('layouts.theme.app')

@section('content')
<div class="container-fluid">

    <div class="row mb-4">
        <div class="col-12">
            <h3 class="fw-bold">Snapshot Revisión Contractual</h3>
            <p class="text-muted">Versión #{{ $snapshot->numero_version }}</p>
        </div>
    </div>

    {{-- RESUMEN --}}
    <div class="card mb-4 shadow-sm">
        <div class="card-header bg-dark text-white">
            <strong>Resumen</strong>
        </div>
        <div class="card-body">
            @php $resumen = $snapshot->json_resultado['resumen'] ?? []; @endphp

            <p><strong>Tipo Contrato:</strong> {{ $resumen['tipo_contrato'] ?? '-' }}</p>
            <p><strong>Entidad:</strong> {{ $resumen['entidad'] ?? '-' }}</p>

            <p>
                <strong>Riesgo General:</strong>
                <span class="badge 
                    @if(($resumen['riesgo_general'] ?? '') == 'alto') bg-danger
                    @elseif(($resumen['riesgo_general'] ?? '') == 'medio') bg-warning text-dark
                    @else bg-success
                    @endif">
                    {{ strtoupper($resumen['riesgo_general'] ?? '-') }}
                </span>
            </p>

            <p><strong>Observaciones Clave:</strong></p>
            <ul>
                @foreach(($resumen['observaciones_clave'] ?? []) as $obs)
                    <li>{{ $obs }}</li>
                @endforeach
            </ul>
        </div>
    </div>

    {{-- HALLAZGOS --}}
    <div class="row mb-4">
        <div class="col-12">
            <h5 class="fw-bold">Hallazgos</h5>
        </div>

        @foreach($snapshot->hallazgos as $h)
        <div class="col-md-6 mb-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h6 class="fw-bold">{{ $h->titulo }}</h6>

                    <p>
                        <span class="badge 
                            @if($h->nivel_criticidad == 'alta') bg-danger
                            @elseif($h->nivel_criticidad == 'media') bg-warning text-dark
                            @else bg-success
                            @endif">
                            {{ strtoupper($h->nivel_criticidad) }}
                        </span>
                        <span class="badge bg-secondary">{{ $h->tipo_riesgo }}</span>
                    </p>

                    <p><strong>Descripción:</strong><br>{{ $h->observacion }}</p>

                    <p><strong>Recomendación:</strong><br>{{ $h->recomendacion }}</p>
                </div>
            </div>
        </div>
        @endforeach
    </div>

    {{-- CHECKLIST --}}
    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white">
            <strong>Checklist de Revisión</strong>
        </div>

        <div class="card-body table-responsive">
            <table class="table table-bordered align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Ítem</th>
                        <th>Estado</th>
                        <th>Observación</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($snapshot->checklist as $c)
                    <tr>
                        <td>{{ $c->orden }}</td>
                        <td>{{ $c->item }}</td>
                        <td>
                            <span class="badge 
                                @if($c->estado_item == 'cumple') bg-success
                                @elseif($c->estado_item == 'no_cumple') bg-danger
                                @elseif($c->estado_item == 'pendiente_verificar') bg-warning text-dark
                                @else bg-secondary
                                @endif">
                                {{ strtoupper($c->estado_item) }}
                            </span>
                        </td>
                        <td>{{ $c->observacion }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

</div>
@endsection
